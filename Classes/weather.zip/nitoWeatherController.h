
#import "nitoWeather.h"

enum 
{
	ntvCreateWeatherPoint = 0,
	ntvEditWeatherPoint = 1,
	
};
typedef int ntvWeatherMode;


@interface nitoWeatherController : BRMediaMenuController
{
	ntvWeatherMode			weatherMode;
	NSMutableDictionary		*weatherDictionary;
	int						_stackPosition;
	id						_parentController;
	NSMutableArray			*_things; //menu items in the main menu
    NSString				*_imageName;
	
	id						theController;
	int						weatherKey;
	long					_currentRow;
	int _kbType;
}

- (long)currentRow;
- (void)setCurrentRow:(long)value;

- (int)weatherKey;
- (void)setWeatherKey:(int)value;

- (ntvWeatherMode)weatherMode;
- (void)setWeatherMode:(ntvWeatherMode)value;

- (NSMutableDictionary *)weatherDictionary;

+ (NSString *) rootMenuLabel;
- (id)parentController;
- (void)setParentController:(id)value;

- (id) init;
- (id) initWithWeather:(nitoWeather *)weatherPoint withMode:(ntvWeatherMode)theMode;
- (void) dealloc;

- (long) controlCount;
- (id) controlAtIndex: (long) row requestedBy:(id)fp12;
- (id) previewControlForItem: (long) row;
- (void) itemSelected: (long) row;

@end
