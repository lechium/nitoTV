
#import "nitoWeather.h"
#import "nitoWeatherController.h"

@class BRControl, BRHeaderControl;

@interface ntvWeatherManager : BRMediaMenuController
{
	int _stackPosition;
	id	_parentController;
	NSMutableArray		*_names;
	NSMutableArray		*_locations;
	NSMutableArray		*_units;
	NSMutableArray      *_locationDicts;
	NSMutableArray		*_keys;
	NSMutableDictionary	*_globalDict;
    NSString *          _imageName;
	int					_listState;
	NSString				*_mainTitle;
	id				theController;
	NSMutableData					*loginReturnData;
	NSArray				*tempWeatherArray;
	nitoWeather			*currentNitoWeather;
}
- (nitoWeather *)currentNitoWeather;
- (void)setCurrentNitoWeather:(nitoWeather *)value;

- (id)globalDict;

- (NSArray *)tempWeatherArray;
- (void)setTempWeatherArray:(NSArray *)value;
- (BOOL)mediaPreviewShouldShowMetadata;
+ (NSString *) rootMenuLabel;
- (id)parentController;
- (void)setParentController:(id)value;

- (id) init;
- (id) initWithArray: (NSArray *) inputArray state: (int) listState andTitle:(NSString *)theTitle;
- (void) dealloc;

- (long) controlCount;
- (id) controlAtIndex: (long) row requestedBy:(id)fp12;
- (id) previewControlForItem: (long) row;
- (void) itemSelected: (long) row;

@end
