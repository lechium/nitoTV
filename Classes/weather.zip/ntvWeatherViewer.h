


@class BRController;

@interface ntvWeatherViewer : BRController
{
    BRHeaderControl *       _header;
    BRTextControl *         _sourceText;
	NSArray *weatherArray;
	NSDictionary *weatherDictionary;
	

}
-(CGRect)frame;
@end
